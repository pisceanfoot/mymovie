##What's this?

This is windwild's track for learning scrapy.

To test this just run

```Shell
scrapy crawl fotomen -o fotomen.json -t json
```

##Versions:
2013.02.22 First scrapy example for downloading fotomen

2013.02.23 Custmized image pipeline
2013.02.24 Star doing 360buy.com Things
